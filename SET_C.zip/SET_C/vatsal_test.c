

#include <stdio.h>

/*Function prototype*/

void wordGenerator(int telephoneNumber[]);

int main()

{

    int telephoneLoop = 0; //counter for loop

    int phone_Number[7] = {0}; //array to store phone number

    printf("Enter the 7 digit phone number, using only the digits 2 to 9:\n"); //prompt user to enter phone number one digit at a time

    while (telephoneLoop <= 6) //Loops seven times to receive phone number

    {

        scanf("%d", &phone_Number[telephoneLoop]);

        while (phone_Number[telephoneLoop] < 2 || phone_Number[telephoneLoop] > 9) //Check if number is between 2 and 9

        {

            printf("\nError: Invalid phone number entered. Please try again: ");

            scanf("%d", &phone_Number[telephoneLoop]);
        }

        telephoneLoop++;
    }

    wordGenerator(phone_Number); // Call function to generate words out of phone numbers

    return 0;

} // End main

void wordGenerator(int telephoneNumber[])

{

    int telephoneLoop; // counter for loop

    //Loops to take 1st - 7th digit of phone number
    int telephoneLoop1;

    int telephoneLoop2;

    int telephoneLoop3;

    int telephoneLoop4;

    int telephoneLoop5;

    int telephoneLoop6;

    int telephoneLoop7;

    // file pointer

    FILE *tpnWg;

    // Letters that correspond to each digit

    char *number_Letters[10] = {"", "", "ABC", "DEF", "GHI", "JKL", "MNO", "PQRS", "TUV", "WXY"};

    if ((tpnWg = fopen("telephone.txt", "r+")) == NULL) //Opens file in write mode

    {

        printf("File cannot be opened.\n");
    }

    else

    {

        //display possible word combos

        //loop to replace first digit

        for (telephoneLoop1 = 0; telephoneLoop1 <= 2; telephoneLoop1++)

        {

            // loop to replace 2nd digit

            for (telephoneLoop2 = 0; telephoneLoop2 <= 2; telephoneLoop2++)

            {

                //Loop for 3rd digit

                for (telephoneLoop3 = 0; telephoneLoop3 <= 2; telephoneLoop3++)

                {

                    //Loop for 4th digit

                    for (telephoneLoop4 = 0; telephoneLoop4 <= 2; telephoneLoop4++)

                    {

                        //Loop for 5th digit

                        for (telephoneLoop5 = 0; telephoneLoop5 <= 2; telephoneLoop5++)

                        {

                            //Loop for 6th digit

                            for (telephoneLoop6 = 0; telephoneLoop6 <= 2; telephoneLoop6++)

                            {

                                //Loop for 7th digit

                                for (telephoneLoop7 = 0; telephoneLoop7 <= 2; telephoneLoop7++)

                                {

                                    fprintf(tpnWg, "%c%c%c%c%c%c%c\n", number_Letters[telephoneNumber[0]][telephoneLoop1], number_Letters[telephoneNumber[1]][telephoneLoop2], number_Letters[telephoneNumber[2]][telephoneLoop3], number_Letters[telephoneNumber[3]][telephoneLoop4], number_Letters[telephoneNumber[4]][telephoneLoop5], number_Letters[telephoneNumber[5]][telephoneLoop6], number_Letters[telephoneNumber[6]][telephoneLoop7]);

                                } //End for

                            } //End for

                        } //End for

                    } //End for

                } //End for

            } //End for

        } //End for

        //Display phone number

        fprintf(tpnWg, "\nPhone number is: ");

        for (telephoneLoop = 0; telephoneLoop <= 6; telephoneLoop++)

        {

            // to insert dash

            if (telephoneLoop == 3)

            {

                fprintf(tpnWg, "-");

            } // End if

            fprintf(tpnWg, "%d", telephoneNumber[telephoneLoop]);

        } // End for loop

    } // End Else

    // file pointer closed

    fclose(tpnWg);
}