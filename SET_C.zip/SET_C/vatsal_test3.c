#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<ctype.h>
/*Macro's define*/
#define SEN_LEN 80
#define MAX_LOPP_ITERATE 20
/*Function prototype*/
int randNumberGen();
char* randSentenceGen();
/*Global array difination*/
char *article[5] = {"the","a","one","some","any"}; 
char *noun[5] = {"boy","girl","dog","town","car"}; 
char *verb[5] = {"drove","jumped","ran","walked","skipped"}; 
char *preposition[5] = {"to","from","over","under","on"}; 

int main(){
    
    for (int  i = 0; i < 20; i++)
    {
        char *sentence =senGen();
        printf("%s.\n",sentence);
        free(sentence);
    }
    return 0 ;


}

int randNumberGen(){
    int num = 0;
    num = rand()  %5;
    return num;
}
char* randSentenceGen(){
    char* sentence = calloc((SEN_LEN+1),sizeof(char));
    strcat(sentence,article[randNumberGen()]);

    strcat(sentence," ");
    strcat(sentence,noun[randNumberGen()]);
    
    strcat(sentence," ");
    strcat(sentence,verb[randNumberGen()]);
    
    strcat(sentence," ");
    strcat(sentence,preposition[randNumberGen()]);

    sentence[0] = toupper(sentence[0]);
    return sentence;
}