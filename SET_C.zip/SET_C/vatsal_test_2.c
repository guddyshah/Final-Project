#include <stdio.h>
/*Function prototype*/
void addition(double num1,double num2);
void subtraction(double num1,double num2);
void multiplication(double num1,double num2);
void divison(double num1,double num2);

int main(){

    int inputChoise  = 1;
    double ipNumber1 = 0;
    double ipNumber2 = 0;

    while(inputChoise >=1 &&inputChoise <=4){
        printf("Press 1 to add two number\n");
        printf("Press 2 to subtract two number\n");
        printf("Press 3 to multiply two number\n");
        printf("Press 4 to divide two number\n");
        printf("Press 5 to Exit\n\n");
        printf("Please Enter Your Choise\n");
        scanf("%d",&inputChoise);
        if (inputChoise == 5){
            printf("Exit successfully");
            return(0);
        }
        else {
            printf("Enter Vaild number \n");
            return(0);
        }
        
        printf("Enter First Number : ");
        scanf("%lf",&ipNumber1);
        printf("Enter Second Number : ");
        scanf("%lf",&ipNumber2);
        /*Function array prototype */
        void (*arrFunc[4])(double,double) = {&addition,&subtraction,&multiplication,&divison};
        (*arrFunc [inputChoise - 1])(ipNumber1,ipNumber2); /*Function array calling */

        return 0 ;
    }

}

void addition(double num1,double num2){
    double result = 0;
    result = num1+num2;
    printf("Addition of two number is = %lf + %lf = %lf \n",num1,num2,result);
    return ;
}
void subtraction(double num1,double num2){
    double result = 0;
    result = num1-num2;
    printf("subtraction of two number is = %lf - %lf = %lf \n",num1,num2,result);
    return ;
}
void multiplication(double num1,double num2){
    double result = 0;
    result = num1*num2;
    printf("multiplication of two number is = %lf X %lf = %lf \n",num1,num2,result);
    return ;
}
void divison(double num1,double num2){
    double result = 0;
    result = num1/num2;
    printf("divison of two number is = %lf / %lf = %lf \n",num1,num2,result);
    return ;
}